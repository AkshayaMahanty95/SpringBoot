package com.ojas.emp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeCurdOperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
